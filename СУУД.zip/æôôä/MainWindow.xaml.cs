﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Text;
using System.Net;
using System.Net.Sockets;
using static System.Console;
using System.Threading;

namespace VIVI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        #region Methods of Window
        private void Close_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Close();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LightOff.IsChecked = true;
            ConOff.IsChecked = true;
            OtoplOff.IsChecked = true;
            Light.Visibility = Visibility.Hidden;
            Cond.Visibility = Visibility.Hidden;
            Otopl.Visibility = Visibility.Hidden;
        }
        #endregion

        #region Methods of Light
        private void LightOff_Checked(object sender, RoutedEventArgs e)
        {
            LightMode.IsEnabled = false;
            LightMode.Text = "";
        }

        private void LightOn_Checked(object sender, RoutedEventArgs e)
        {
            LightMode.IsEnabled = true;
            LightMode.SelectedIndex = 3;
        }

        private void LightOk_Click(object sender, RoutedEventArgs e)
        {
            // Настраиваем подключение
            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse("169.254.10.96"), 9090);

            // создаем сокет
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                // присоединяем сокет к Raspberry Pi
                socket.Connect(ipPoint);

                // отправляем данные
                if (LightOn.IsChecked == true)
                    switch (LightMode.SelectedIndex)
                    {
                        case 3:
                            socket.Send(Encoding.UTF8.GetBytes("255"));
                            break;
                        case 0:
                            socket.Send(Encoding.UTF8.GetBytes("65"));
                            break;
                        case 1:
                            socket.Send(Encoding.UTF8.GetBytes("130"));
                            break;
                        case 2:
                            socket.Send(Encoding.UTF8.GetBytes("190"));
                            break;
                    }
                else socket.Send(Encoding.UTF8.GetBytes("0"));

                // закрываем сокет
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();

            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }
        #endregion

        #region Methods of Cond
        private void Down_Checked(object sender, RoutedEventArgs e)
        {
            Up.IsChecked = false;
            DownBox.IsReadOnly = false;
            DownBox.Focus();
            UpBox.Text = "";
            UpBox.IsReadOnly = true;
        }

        private void Up_Checked(object sender, RoutedEventArgs e)
        {
            Down.IsChecked = false;
            UpBox.IsReadOnly = false;
            UpBox.Focus();
            DownBox.Text = "";
            DownBox.IsReadOnly = true;
        }

        private void ConOff_Checked(object sender, RoutedEventArgs e)
        {
            TempCon.IsEnabled = false;
            Up.IsChecked = false;
            UpBox.Text = "";
            Down.IsChecked = false;
            DownBox.Text = "";
            Turbo.IsEnabled = false;
            Turbo.IsChecked = false;
        }

        private void ConOn_Checked(object sender, RoutedEventArgs e)
        {
            TempCon.IsEnabled = true;
            DownBox.IsReadOnly = true;
            UpBox.IsReadOnly = true;
            Turbo.IsEnabled = true;
        }

        private void CondOk_Click(object sender, RoutedEventArgs e)
        {
            if (DownBox.Text != "" && Convert.ToInt16(DownBox.Text) > Convert.ToInt16(Temp.Text))
                 MessageBox.Show("Температура понижения не может быть больше текущей температуры");
            else if (UpBox.Text != "" && Convert.ToInt16(UpBox.Text) < Convert.ToInt16(Temp.Text))
                MessageBox.Show("Температура повышения не может быть меньше текущей температуры");
            else if (Down.IsChecked == true && Convert.ToInt16(DownBox.Text) < 18)
                MessageBox.Show("Кондиционер не может понижать температуру ниже 18 градусов");
            else if (Up.IsChecked == true && Convert.ToInt16(UpBox.Text) > 30)
                MessageBox.Show("Кондиционер не может повышать температуру выше 30 градусов");
            else if (ConOn.IsChecked==true && Down.IsChecked==false && Up.IsChecked==false)
                MessageBox.Show("Выберите одно из действий");
            else
            {
                // Настраиваем подключение
                IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse("169.254.10.96"), 7000);

                // создаем сокет
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    // присоединяем сокет к Raspberry Pi
                    socket.Connect(ipPoint);

                    // отправляем данные
                    if (ConOn.IsChecked == true)
                    {
                        if (Up.IsChecked == true)
                                 socket.Send(Encoding.UTF8.GetBytes(UpBox.Text));
                        else if (Down.IsChecked == true)
                                 socket.Send(Encoding.UTF8.GetBytes(DownBox.Text));
                    }
                    else socket.Send(Encoding.UTF8.GetBytes("0"));

                    // получаем температуру
                    StringBuilder builder = new StringBuilder();
                    int bytes = 0; // количество полученных байтов
                    byte[] data = new byte[256]; // буфер для получаемых данных

                    do
                    {
                        bytes = socket.Receive(data, data.Length, 0);
                        builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
                    } while (socket.Available > 0);

                    Temp.Text = builder.ToString().Trim();

                    // закрываем сокет
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();

                }
                catch (Exception ex)
                {
                    WriteLine(ex.Message);
                }
            }
        }
        #endregion

        #region Methods of Otopl
        private void OtoplOff_Checked(object sender, RoutedEventArgs e)
        {
            OtoplOn.IsChecked = false;
            OtoplOff.IsChecked = true;
            TempOtopl.IsEnabled = false;
            UpOtopl.IsChecked = false;
            UpOtoplBox.Text = "";
            DownOtopl.IsChecked = false;
            DownOtoplBox.Text = "";
        }

        private void OtoplOn_Checked(object sender, RoutedEventArgs e)
        {
            TempOtopl.IsEnabled = true;
            UpOtoplBox.IsReadOnly = true;
            DownOtoplBox.IsReadOnly = true;
        }

        private void UpOtopl_Checked(object sender, RoutedEventArgs e)
        {
            DownOtopl.IsChecked = false;
            UpOtoplBox.IsReadOnly = false;
            UpOtoplBox.Focus();
            DownOtoplBox.Text = "";
            DownOtoplBox.IsReadOnly = true;
        }

        private void DownOtopl_Checked(object sender, RoutedEventArgs e)
        {
            UpOtopl.IsChecked = false;
            DownOtoplBox.IsReadOnly = false;
            DownOtoplBox.Focus();
            UpOtoplBox.Text = "";
            UpOtoplBox.IsReadOnly = true;
        }

        private void OtoplOk_Click(object sender, RoutedEventArgs e)
        {
            if (DownOtoplBox.Text != "" && Convert.ToInt16(DownOtoplBox.Text) >= Convert.ToInt16(TempInside.Text))
                MessageBox.Show("Температура понижения не может быть больше или равной текущей температуры");
            else if (UpOtoplBox.Text != "" && Convert.ToInt16(UpOtoplBox.Text) <= Convert.ToInt16(TempInside.Text))
                MessageBox.Show("Температура повышения не может быть меньше или равной текущей температуры");
            else if (DownOtopl.IsChecked == true && DownOtoplBox.Text == "")
                MessageBox.Show("Укажите до какой температуры нужно снизить");
            else if (DownOtopl.IsChecked == true && Convert.ToInt16(DownOtoplBox.Text) <= 10)
            {
                MessageBox.Show("При температуре помещения меньше или равной 10 градусов\nсистема отопления будет отключена");
                OtoplOff_Checked(sender, e);
            }
            else if (UpOtopl.IsChecked == true && UpOtoplBox.Text == "")
                MessageBox.Show("Укажите до какой температуры нужно повышать");
            else if (UpOtopl.IsChecked == true && Convert.ToInt16(UpOtoplBox.Text) > 40)
                MessageBox.Show("Система отопления не может повысить температуру выше 40 градусов");
            else if (OtoplOn.IsChecked == true && UpOtopl.IsChecked == false && DownOtopl.IsChecked == false)
                MessageBox.Show("Выберите, что надо сделать системе");
            else
            {
                // Настраиваем подключение
                IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse("169.254.10.96"), 8005);

                // создаем сокет
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    // присоединяем сокет к Raspberry Pi
                    socket.Connect(ipPoint);

                    // отправляем данные
                    if (OtoplOn.IsChecked == true)
                    {
                        if (UpOtopl.IsChecked == true)
                            socket.Send(Encoding.UTF8.GetBytes(UpOtoplBox.Text));
                        else if (DownOtopl.IsChecked == true)
                            socket.Send(Encoding.UTF8.GetBytes(DownOtoplBox.Text));
                    }
                    else socket.Send(Encoding.UTF8.GetBytes("0"));

                    // получаем температуру
                    StringBuilder builder = new StringBuilder();
                    int bytes = 0; // количество полученных байтов
                    byte[] data = new byte[256]; // буфер для получаемых данных

                    do
                    {
                        bytes = socket.Receive(data, data.Length, 0);
                        builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
                    } while (socket.Available > 0);

                    TempInside.Text = builder.ToString().Trim();

                    // закрываем сокет
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();

                }
                catch (Exception ex)
                {
                    WriteLine(ex.Message);
                }
            }
        }
        #endregion

        #region Methods of Icon

        bool isLightInHall = false;
        bool isOtopl = false;
        bool isCondInLiving = false;

        private void LightInHall_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isLightInHall)
            {
                Light.Visibility = Visibility.Visible;
                isLightInHall = true;
            }
            else
            {
                Light.Visibility = Visibility.Hidden;
                isLightInHall = false;
            }
        }

        private void CondInLiving_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isCondInLiving)
            {
                Cond.Visibility = Visibility.Visible;
                isCondInLiving = true;
            }
            else
            {
                Cond.Visibility = Visibility.Hidden;
                isCondInLiving = false;
            }
        }

        private void OtoplIcon_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isOtopl)
            {
                Otopl.Visibility = Visibility.Visible;
                isOtopl = true;
            }
            else
            {
                Otopl.Visibility = Visibility.Hidden;
                isOtopl = false;
            }
        }
        #endregion

    }
}